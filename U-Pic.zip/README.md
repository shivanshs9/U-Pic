# U-Pic
http://upic.eu-gb.mybluemix.net
It's more or less an image viewer. To upload images, first the person has to be registered and then upload their images using their account. The account details and images information are stored in MySQL database, so it'll have to be setup too.

Since the Bluemix hosted site has database issues and more-or-less file-uploading issues, I've decided to give the required database tables too. Setup the database according to the information in appvars.php file under files directory.